<!-- Main Footer -->
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
{{-- <script src={{asset("public/adminlte/plugins/jquery/jquery.min.js")}}></script> --}}
<!-- Bootstrap -->
<script src={{asset("public/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js")}}></script>
<!-- overlayScrollbars -->
<script src={{asset("public/adminlte/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js")}}></script>
<!-- AdminLTE App -->
<script src={{asset("public/adminlte/dist/js/adminlte.js")}}></script>
<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src={{asset("public/adminlte/plugins/jquery-mousewheel/jquery.mousewheel.js")}}></script>
<script src={{asset("public/adminlte/plugins/raphael/raphael.min.js")}}></script>
<script src={{asset("public/adminlte/plugins/jquery-mapael/jquery.mapael.min.js")}}></script>
<script src={{asset("public/adminlte/plugins/jquery-mapael/maps/usa_states.min.js")}}></script>
<!-- ChartJS -->
<script src={{asset("public/adminlte/plugins/chart.js/Chart.min.js")}}></script>
</body>
</html>