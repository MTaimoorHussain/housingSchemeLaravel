<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlotType extends Model
{
    protected $fillable = [
        'plotType'
    ]; 
}
