<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocietyLayoutPlan extends Model
{
    protected $fillable = [
        'plotTypeName','noOfPlots'
    ];
}
